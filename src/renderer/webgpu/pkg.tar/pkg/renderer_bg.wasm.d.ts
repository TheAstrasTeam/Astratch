/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const run: () => void;
export const wasm_bindgen_7615e7c178744903___convert__closures_____invoke___wasm_bindgen_7615e7c178744903___JsValue__core_f0fd674eaa06beef___result__Result_____wasm_bindgen_7615e7c178744903___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_7615e7c178744903___convert__closures_____invoke___wasm_bindgen_7615e7c178744903___sys__JsOption_wgpu_11b4b5339fb8319___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_f0fd674eaa06beef___result__Result_____wasm_bindgen_7615e7c178744903___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_7615e7c178744903___convert__closures_____invoke___wasm_bindgen_7615e7c178744903___sys__JsOption_wgpu_11b4b5339fb8319___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_f0fd674eaa06beef___result__Result_____wasm_bindgen_7615e7c178744903___JsError___true__2: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_7615e7c178744903___convert__closures_____invoke___wasm_bindgen_7615e7c178744903___sys__JsOption_wgpu_11b4b5339fb8319___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_f0fd674eaa06beef___result__Result_____wasm_bindgen_7615e7c178744903___JsError___true__3: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_7615e7c178744903___convert__closures_____invoke_______true_: (a: number, b: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
